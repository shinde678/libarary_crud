from crud.views import BookView
from rest_framework.routers import DefaultRouter
from crud import views

router = DefaultRouter()
router.register(r'bookcrud', views.BookView, basename='bookcrud')
urlpatterns = router.urls
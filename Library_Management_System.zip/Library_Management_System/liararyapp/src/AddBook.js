import { useState, useEffect } from "react";
import { Button, Form } from "react-bootstrap";
import API from "./API";


const AddBook = ({ onAdd }) => {
  const [book_name, setBookName] = useState("");
  const [book_price, setBookPrice] = useState("");
  const [author, setAuthor] = useState("");
  const [bookid, setBookId] = useState(null);
  const [books, setBooks] = useState([]);

  useEffect(() => {
    refresh();
  }, []);

  const refresh = () => {
    API.get("/")
      .then((res) => {
        setBooks(res.data);
        console.log(res.data)
      })
      .catch(console.error);
  };

  const onSubmit = (e) => {
    e.preventDefault();
    let item = { book_name, book_price, author };
    
    API.post("/", item).then((res) => refresh());

  };

  const onUpdate = (pk) => {
    let item = { book_name, book_price, author };
    API.patch(`/${pk}/`, item).then((res) => refresh());
    
  };

  const onDelete = (pk) => {
     API.delete(`/${pk}/`).then((res) => refresh());

  };

  function selectBooks(pk) {
    let item = books.filter((book) => book.pk === pk)[0];
    setBookName(item.book_name);
    setBookPrice(item.book_price);
    setAuthor(item.author);
    setBookId(item.pk);
  }

  return (
    <div className="container mt-5">
      <div className="row">
        <div className="col-md-4">
          <h3 className="float-left">Add New Book</h3>
          <Form onSubmit={onSubmit} className="mt-4">
            <Form.Group className="mb-3" controlId="formBasicName">
              <Form.Label>{bookid}Book Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Book name"
                value={book_name}
                onChange={(e) => setBookName(e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicGenre">
              <Form.Label>Price</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Price"
                value={book_price}
                onChange={(e) => setBookPrice(e.target.value)}
              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicStarring">
              <Form.Label>Author</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter Author"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
              />
            </Form.Group>

            <div className="float-right">
              <Button
                variant="primary"
                type="submit"
                onClick={onSubmit}
                className="mx-2"
              >
                Save
              </Button>
              <Button
                variant="primary"
                type="button"
                onClick={() => onUpdate(bookid)}
                className="mx-2"
              >
                Update
              </Button>
            </div>
          </Form>
        </div>
        <div className="col-md-8 m">
          <table class="table">
            <thead>
              <tr>
                <th scope="col">index</th>
                <th scope="col">Book Name</th>
                <th scope="col">Price</th>
                <th scope="col">Author</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {books.map((book, index) => {
                return (
                  <tr key="">
                    <th scope="row">{book.pk}</th>
                    <td> {book.book_name}</td>
                    <td>{book.book_price}</td>
                    <td>{book.author}</td>
                  
                    <td>
                      <button className="btn btn-sm btn-primary mr-2" onClick={() => selectBooks(book.pk)}>Edit</button>
                      <button className="btn btn-sm btn-danger" onClick={() => onDelete(book.pk)}>Delete</button>
                     
                      
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AddBook;
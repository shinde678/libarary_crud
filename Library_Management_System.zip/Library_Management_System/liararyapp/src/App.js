
import 'bootstrap/dist/css/bootstrap.min.css';

import './App.css';
import AddBook from './AddBook'

function App() {
   
  return (
    <div className="App">
      <AddBook/>
      
    </div>
  );
}

export default App;